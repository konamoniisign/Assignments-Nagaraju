package com.Assignment.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Assignment.Model.Department;
import com.Assignment.Model.Employee;
import com.Assignment.Repository.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepo employeeRepository;
	
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }
	
	 public Optional<Employee> findById(Long id) {
	        return employeeRepository.findById(id);
	    }

	    public List<Employee> findByDepartmentId(Long departmentId) {
	        return employeeRepository.findByDepartmentId(departmentId);
	    }

	    public Employee save(Employee employee) {
	        return employeeRepository.save(employee);
	    }

	    public void deleteById(Long id) {
	        employeeRepository.deleteById(id);
	    }

	    public List<Employee> findAllWithDepartments() {
	        return employeeRepository.findAll().stream().map(employee -> {
	            Department department = employee.getDepartment();
	            employee.setDepartment(department);
	            return employee;
	        }).collect(Collectors.toList());
	    }

}
