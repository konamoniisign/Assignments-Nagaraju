package com.Assignment.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Assignment.Model.Department;
import com.Assignment.Service.DepartmentService;
import com.Assignment.Service.EmployeeService;

public class DepartmentController {
	
	@Autowired
    private DepartmentService departmentService;

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public List<Department> findAll() {
        return departmentService.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Department> findById(@PathVariable Long id) {
        return departmentService.findById(id);
    }

    @PostMapping("/save")
    public Department save(@RequestBody Department department) {
        return departmentService.save(department);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        departmentService.deleteById(id);
    }

    @GetMapping("/with-employees/{id}")
    public Optional<Department> findDepartmentWithEmployees(@PathVariable Long id) {
        return departmentService.findById(id).map(department -> {
            department.setEmployees(employeeService.findByDepartmentId(id));
            return department;
        });
    }
    
   

    

}
