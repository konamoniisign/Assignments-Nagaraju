package com.Assignment.Model;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class Department {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String departmentName;
	private String createdByUsername;
	private LocalDateTime createdDateTime;
	
	private LocalDateTime updatedDateTime;
	private String updatedByUsername;
	
	@OneToMany(mappedBy = "department", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Employee> employees;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getCreatedByUsername() {
		return createdByUsername;
	}
	public void setCreatedByUsername(String createdByUsername) {
		this.createdByUsername = createdByUsername;
	}
	public LocalDateTime getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(LocalDateTime createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public LocalDateTime getUpdatedDateTime() {
		return updatedDateTime;
	}
	public void setUpdatedDateTime(LocalDateTime updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public String getUpdatedByUsername() {
		return updatedByUsername;
	}
	public void setUpdatedByUsername(String updatedByUsername) {
		this.updatedByUsername = updatedByUsername;
	}
	public Department(Long id, String departmentName, String createdByUsername, LocalDateTime createdDateTime,
			LocalDateTime updatedDateTime, String updatedByUsername) {
		super();
		this.id = id;
		this.departmentName = departmentName;
		this.createdByUsername = createdByUsername;
		this.createdDateTime = createdDateTime;
		this.updatedDateTime = updatedDateTime;
		this.updatedByUsername = updatedByUsername;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public Department(List<Employee> employees) {
		super();
		this.employees = employees;
	}
	
	
	
	

}
